import { homescreenappPlugin } from './plugin';

describe('homescreenapp', () => {
  it('should export plugin', () => {
    expect(homescreenappPlugin).toBeDefined();
  });
});
