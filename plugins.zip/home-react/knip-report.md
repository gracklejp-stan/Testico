# Knip report

## Unused devDependencies (1)

| Name                     | Location     | Severity |
| :----------------------- | :----------- | :------- |
| @types/react-grid-layout | package.json | error    |

