module.exports = require('@backstage/cli/config/eslint-factory')(__dirname, {
  rules: {
    '@backstage/no-top-level-material-ui-4-imports': 'error',
  },
});
